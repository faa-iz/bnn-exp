git add *
git commit -m 'a'
git push
